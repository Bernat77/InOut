/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prueba;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public class Prueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      writeDocument("HOLA ;3");
    }

    public static void readDocument() {
        try {
            Path file = FileSystems.getDefault().getPath("archivos/ranking.txt");
            byte[] fileArray;
            fileArray = Files.readAllBytes(file);
            System.out.print(Arrays.toString(fileArray));
        } catch (IOException e) {
            System.out.print("No se encontró el archivo.");

        }
    }
    
    
    public static void writeDocument(String a){
        try {
            Path file = FileSystems.getDefault().getPath("archivos/ranking.txt");
            byte[] fileArray;
            fileArray = a.getBytes(Charset.forName("UTF-8"));
            Files.write(file,fileArray);
        } catch (Exception e) {
            System.out.print("tuputamadre");
        }
    }

}
